using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Character_Stats : MonoBehaviour
{
    public int Maxhealth = 100;
    public int Current_Health {get; private set;}
    public Player_life Player_Life;
    //当前生命值,全局设置，私有修改的变量

    public Stat Damage;//整型状态机，本质是一个

    void Update() 
    {
        Damage_Chack();
    }

    void Awake()
    {
        Current_Health = Maxhealth;
    }

    public void Take_Damage (int Damage)
    {
        Damage = Mathf.Clamp(Damage,0,int.MaxValue);//伤害范围限制在0和最大生命值直接
        Current_Health -= Damage;

        Debug.Log(transform.name + "takes" + Damage + "damage");
        if (Current_Health <= 0)
        {
        Current_Health = 0;
        Player_Life.Death();
        }
        //玩家受到伤害时，反馈消息
    }

    void Damage_Chack()
    {
        if(Input.GetKeyDown(KeyCode.C))
        {
            Take_Damage(10);
        }    
    }
            [SerializeField]
        public int BaseValue;

            public int GetValue()
        {
            return BaseValue;
        }
}
