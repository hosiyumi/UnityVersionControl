
using UnityEngine;


    [System.Serializable]// 系统可视化
    public class Stat//
    {
        [SerializeField]
        private int BaseValue;

        public int GetValue()
        {
            return BaseValue;
        }
    }
public class Stats : MonoBehaviour
{
    
}
