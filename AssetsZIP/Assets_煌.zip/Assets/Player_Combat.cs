using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Assertions.Must;

[RequireComponent(typeof(Character_Stats))]
public class Player_Combat : MonoBehaviour
{
   Character_Stats character_Stats;
    private void Start() 
    {
        character_Stats = GetComponent<Character_Stats>();
    }

    public void Attack(Character_Stats character_Stats)
    {
        character_Stats.Take_Damage(character_Stats.Damage.GetValue());
        //历史错误：不存在State，
    }


}
