using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Enemy_Behaviour : MonoBehaviour
{
    public float Look_Radius;
    Transform Target;   

    void Start()
    {
        Target = Player_Mannager.instance.Player.transform;
    }

    // void Update()
    // {
    // //  float  distance = Vector2.Distance(Target.position,transform.position);

    //  if (distance <=Look_Radius)
    //  {
    //     //AI寻路逻辑
    //  }
    // }

    private void OnDrawGizmosSelected() 
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position , Look_Radius);
        //绘制线框球体，半径为视线距离，线的颜色位蓝色
    }
}
