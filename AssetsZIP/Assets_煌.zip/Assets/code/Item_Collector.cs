

public class Item_Collector : MonoBehaviour
{
    public Character_Stats Character_Stats;

    [SerializeField] private Text Text_1;
    [SerializeField] private Text Text_2;
    [SerializeField] private AudioSource collectsound;

    int Ammunition = 0;

    private void Update() 
    {
            Text_1.text = "HP:" + Character_Stats.Current_Health;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("cherry"))
        {
             Destroy(collision.gameObject);

             collectsound.Play();
             //碰撞到带有樱桃标签的对象时，销毁对象并使玩家获得的樱桃+1，播放拾取的音源
        }

        if (collision.gameObject.CompareTag("Ammunition"))
        {
            Ammunition +=3;
            Destroy(collision.gameObject);
            Text_2.text = "Ammunition:" + Ammunition;
            collectsound.Play();
            //碰撞到带有弹药标签的对象时，销毁对象并使玩家的弹药+3（后面允许扩容弹夹或快速弹夹，弹药上限为6或更快的播放动画），播放拾取的音源
        }

   
    }
    
}
