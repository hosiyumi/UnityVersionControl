using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Mannager : MonoBehaviour
{
#region Singelton
public static Player_Mannager instance;
void Awake()
    {
        instance = this;
    }
#endregion
public GameObject Player;
}
