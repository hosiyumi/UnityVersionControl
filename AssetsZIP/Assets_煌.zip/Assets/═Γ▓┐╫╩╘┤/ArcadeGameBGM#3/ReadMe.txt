Arcade Game BGM #3

It is a game sound with a theme of Arcade game.

Two versions are included.

Full ver & Loop Ver.

It is free. It is freely usable.

Do not resell.

--------Contents-----

ArcadeGameBGM#3_Full - Full Ver/ WAV/ BPM 110/ 02:26

ArcadeGameBGM#3_Loop - Loop Ver/ WAV/ BPM 110/ 01:09


If you have any problems with the product, please contact us by e-mail.

4crain@gmail.com