using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class tiletest : MonoBehaviour
{
public Tile tile;
public Tile tile1;
public TileBase tileBase;
public TilemapRenderer tilemapRenderer;
public TilemapCollider2D tilemapCollider2D;

}
